# Child Safety — Android Studio starter project

A runnable Kotlin + Jetpack Compose starter with two separate Android apps:
- `:parentApp`: Smart parent dashboard UI with feature cards and demo child status.
- `:childApp`: child-side onboarding, visible permission status, and usage-access setup entry point.

## Open and run
1. Install Android Studio with Android SDK.
2. Extract this ZIP and open the `ChildSafety` folder.
3. Let Gradle sync. Use JDK 17 (Android Studio's embedded JDK is fine).
4. Run `parentApp` on one device/emulator.
5. Select `childApp` as the run configuration for the child-side app.

## Important scope
This is a UI/project starter, not a complete remote-monitoring system. Dashboard cards that are not implemented are clearly marked as "Setup required" and do not pretend to stream data. Usage Access opens Android's system settings; actual reporting, secure pairing/backend, location, and user-consented screen sharing are later integration steps. Camera/microphone are not accessed covertly.

## Modules
- `parentApp`: package `com.example.childsafety.parent`
- `childApp`: package `com.example.childsafety.child`

## Next implementation steps
1. Add Firebase Authentication and secure, per-device pairing with one-time codes.
2. Implement local app usage reporting in `childApp` using `UsageStatsManager` after the user grants Usage Access.
3. Add foreground location sharing with explicit permission and clear status.
4. Add user-started screen sharing using `MediaProjection` and a secure streaming service.
5. Add security rules, revocation, retention controls, and real-device tests.

Never commit `google-services.json`, service-account keys, passwords, or other secrets to source control.
