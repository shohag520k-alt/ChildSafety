package com.example.childsafety.child

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF17213A)
private val Blue = Color(0xFF4768F5)
private val Grey = Color(0xFF7B8499)

class ChildActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                ChildHome(
                    hasUsageAccess = { usageAccessGranted() },
                    openUsageSettings = {
                        startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                    }
                )
            }
        }
    }

    private fun usageAccessGranted(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return ops.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            packageName
        ) == AppOpsManager.MODE_ALLOWED
    }

    override fun onResume() {
        super.onResume()
        // Compose screen checks the permission whenever its button is pressed.
    }
}

@Composable
private fun ChildHome(hasUsageAccess: () -> Boolean, openUsageSettings: () -> Unit) {
    var usageGranted by remember { mutableStateOf(hasUsageAccess()) }
    Surface(color = Color(0xFFF4F6FB), modifier = Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).background(Brush.linearGradient(listOf(Color(0xFF263B91), Color(0xFF5979F8))), CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Shield, null, tint = Color.White)
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("CHILD SAFETY", color = Grey, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                    Text("Child device setup", color = Navy, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
            }
            Surface(shape = RoundedCornerShape(22.dp), color = Color.White) {
                Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(Icons.Default.ChildCare, null, tint = Blue, modifier = Modifier.size(36.dp))
                    Text("Welcome", color = Navy, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("This device is not paired with a parent yet. Pairing and monitoring settings will be explained clearly before they are enabled.", color = Grey, fontSize = 14.sp, lineHeight = 20.sp)
                    OutlinedButton(onClick = { usageGranted = hasUsageAccess(); openUsageSettings() }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.QueryStats, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Set up app usage access")
                    }
                    Text(
                        if (usageGranted) "Usage access: enabled" else "Usage access: not enabled",
                        color = if (usageGranted) Color(0xFF16866D) else Color(0xFFB66B16),
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp
                    )
                    Button(onClick = { usageGranted = hasUsageAccess() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Refresh permission status")
                    }
                }
            }
            Surface(shape = RoundedCornerShape(18.dp), color = Color(0xFFE9EEFF)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
                    Icon(Icons.Default.Lock, null, tint = Blue)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("Privacy & control", color = Navy, fontWeight = FontWeight.Bold)
                        Text("This starter does not hide itself or secretly access the camera, microphone or screen. Each future feature will request the appropriate Android permission and show its status.", color = Grey, fontSize = 12.sp, lineHeight = 17.sp)
                    }
                }
            }
        }
    }
}
