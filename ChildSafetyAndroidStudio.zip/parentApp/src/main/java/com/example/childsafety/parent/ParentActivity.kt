package com.example.childsafety.parent

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF17213A)
private val Muted = Color(0xFF7B8499)
private val Blue = Color(0xFF4768F5)
private val Pale = Color(0xFFF4F6FB)

class ParentActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { ParentDashboard() } }
    }
}

private data class Feature(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val tint: Color
)

@Composable
private fun ParentDashboard() {
    var selected by remember { mutableStateOf("Dashboard") }
    var activeFeature by remember { mutableStateOf<Feature?>(null) }
    val features = listOf(
        Feature("Live Screen", "Screen sharing", Icons.Default.ScreenShare, Color(0xFF5273F7)),
        Feature("App Usage", "Daily activity", Icons.Default.QueryStats, Color(0xFF22A699)),
        Feature("Location", "Last update", Icons.Default.LocationOn, Color(0xFFEA9A42)),
        Feature("Remote Camera", "Consent-based session", Icons.Default.Videocam, Color(0xFF9164E8)),
        Feature("Audio Session", "Start with consent", Icons.Default.Mic, Color(0xFFDB6484)),
        Feature("App Control", "Limits & rules", Icons.Default.Apps, Color(0xFF3887D9)),
        Feature("Web Safety", "Filtering setup", Icons.Default.Language, Color(0xFF16A6A1)),
        Feature("Alerts", "Safety notifications", Icons.Default.NotificationsActive, Color(0xFFEA8B37)),
        Feature("Device Status", "Battery & connection", Icons.Default.Phonelink, Color(0xFF6875D9)),
        Feature("Settings", "Permissions & privacy", Icons.Default.Settings, Color(0xFF687386))
    )

    Scaffold(
        containerColor = Pale,
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                listOf(
                    Triple("Dashboard", Icons.Default.Dashboard, "Home"),
                    Triple("Activity", Icons.Default.BarChart, "Activity"),
                    Triple("Devices", Icons.Default.Devices, "Devices"),
                    Triple("Settings", Icons.Default.Settings, "Settings")
                ).forEach { (label, icon, content) ->
                    NavigationBarItem(
                        selected = selected == label,
                        onClick = { selected = label; activeFeature = null },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(content) }
                    )
                }
            }
        }
    ) { padding ->
        if (activeFeature != null) {
            FeatureDetail(activeFeature!!, onBack = { activeFeature = null }, modifier = Modifier.padding(padding))
        } else {
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())
            ) {
                Box(
                    modifier = Modifier.fillMaxWidth()
                        .background(Brush.linearGradient(listOf(Color(0xFF263B91), Color(0xFF5979F8))))
                        .padding(start = 22.dp, end = 22.dp, top = 22.dp, bottom = 28.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha=.18f)), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Shield, null, tint = Color.White, modifier = Modifier.size(25.dp))
                            }
                            Spacer(Modifier.width(11.dp))
                            Column(Modifier.weight(1f)) {
                                Text("CHILD SAFETY", color = Color.White.copy(alpha=.8f), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                                Text("Parent Dashboard", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                            }
                            IconButton(onClick = { activeFeature = features.first { it.title == "Alerts" } }) {
                                Icon(Icons.Default.NotificationsNone, "Alerts", tint = Color.White)
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color.White.copy(alpha=.13f)).padding(15.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(54.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.ChildCare, null, tint = Blue, modifier = Modifier.size(31.dp))
                            }
                            Spacer(Modifier.width(13.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Child device", color = Color.White.copy(alpha=.75f), fontSize = 12.sp)
                                Text("Not connected yet", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                                Text("Pair a child device to begin", color = Color.White.copy(alpha=.8f), fontSize = 12.sp)
                            }
                            Surface(color = Color(0xFFFFE8B5), shape = RoundedCornerShape(50)) {
                                Text("SETUP", modifier = Modifier.padding(horizontal=10.dp, vertical=6.dp), color=Color(0xFF805400), fontSize=10.sp, fontWeight=FontWeight.Bold)
                            }
                        }
                    }
                }
                Column(Modifier.padding(horizontal=18.dp, vertical=18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("Overview", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        StatCard("Screen time", "—", "Awaiting device", Icons.Default.Timelapse, Color(0xFFE9EEFF), Blue, Modifier.weight(1f))
                        StatCard("Device status", "Offline", "Not paired", Icons.Default.WifiOff, Color(0xFFFFF0E4), Color(0xFFD8832D), Modifier.weight(1f))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Monitoring tools", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.weight(1f))
                        Text("${features.size} features", fontSize = 12.sp, color = Muted)
                    }
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        modifier = Modifier.fillMaxWidth().heightIn(max = 900.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        userScrollEnabled = false
                    ) {
                        items(features) { feature ->
                            FeatureCard(feature) { activeFeature = feature }
                        }
                    }
                    Surface(shape = RoundedCornerShape(18.dp), color = Color.White) {
                        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.Top) {
                            Icon(Icons.Default.Info, null, tint = Blue)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text("Privacy-first monitoring", color = Ink, fontWeight = FontWeight.SemiBold)
                                Text("Live screen, camera and audio sessions require supported devices and explicit system permission. Features not configured yet will be shown as setup required.", color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, note: String, icon: ImageVector, bg: Color, tint: Color, modifier: Modifier = Modifier) {
    Surface(modifier, shape = RoundedCornerShape(18.dp), color = Color.White) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(bg), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = tint)
            }
            Text(title, color = Muted, fontSize = 12.sp)
            Text(value, color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(note, color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun FeatureCard(feature: Feature, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        color = Color.White,
        shadowElevation = 1.dp
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(feature.tint.copy(alpha=.12f)), contentAlignment = Alignment.Center) {
                Icon(feature.icon, contentDescription = feature.title, tint = feature.tint, modifier = Modifier.size(25.dp))
            }
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(feature.title, color = Ink, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text(feature.subtitle, color = Muted, fontSize = 11.sp, lineHeight = 14.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Setup required", color = feature.tint, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.ChevronRight, null, tint = Muted, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
private fun FeatureDetail(feature: Feature, onBack: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().background(Pale).padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
            Text(feature.title, color = Ink, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        }
        Surface(shape = RoundedCornerShape(24.dp), color = Color.White) {
            Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.size(76.dp).clip(RoundedCornerShape(24.dp)).background(feature.tint.copy(alpha=.12f)), contentAlignment = Alignment.Center) {
                    Icon(feature.icon, null, tint = feature.tint, modifier = Modifier.size(40.dp))
                }
                Text(feature.title, color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("This feature is not connected yet.", color = Muted)
                Text("The dashboard card and navigation work. The real API, permissions, backend and device testing must be added before this feature can be used.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
                Button(onClick = onBack) { Text("Back to dashboard") }
            }
        }
    }
}
